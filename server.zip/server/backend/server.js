require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const multer = require('multer');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const si = require('systeminformation');
const { v4: uuidv4 } = require('uuid');
const { exec, spawn } = require('child_process');
const screenshot = require('screenshot-desktop');
const db = require('./database');
const { authenticate, authorizeAdmin } = require('./auth');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE']
  }
});

const PORT = process.env.PORT || 8080;
// We now base everything off the C: drive as requested.
const ROOT_DIR = 'C:\\';
const JWT_SECRET = process.env.JWT_SECRET;

app.use(cors());
app.use(express.json());

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000,
  message: 'Too many requests, please try again later.'
});
app.use(limiter);

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const safePathInput = req.body.path || req.query.path || '';
    const safePath = path.normalize(safePathInput).replace(/^(\.\.(\/|\\|$))+/, '');
    const targetPath = path.join(ROOT_DIR, safePath);
    
    const normalizedTarget = path.normalize(targetPath).toLowerCase();
    const normalizedRoot = path.normalize(ROOT_DIR).toLowerCase();
    
    // Never attempt to ensureDir on root drive
    if (normalizedTarget !== normalizedRoot && normalizedTarget !== 'c:\\' && normalizedTarget !== 'c:') {
      fs.ensureDirSync(targetPath);
    }
    cb(null, targetPath);
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});
const upload = multer({ storage });

const logActivity = (userId, action, details) => {
  db.run("INSERT INTO activity_logs (userId, action, details) VALUES (?, ?, ?)", [userId, action, details]);
  io.emit('activity_update');
};

// Helper to safely resolve paths against C:\
const resolveSafePath = (userPath) => {
  if (!userPath) return ROOT_DIR;
  const safePath = path.normalize(userPath).replace(/^(\.\.(\/|\\|$))+/, '');
  return path.join(ROOT_DIR, safePath);
};

// --- AUTH ROUTES ---
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  db.get("SELECT * FROM users WHERE username = ?", [username], async (err, user) => {
    if (err || !user) return res.status(401).json({ error: 'Invalid credentials' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Invalid credentials' });

    const payload = {
      id: user.id,
      username: user.username,
      role: user.role,
      canUpload: user.canUpload == 1 || user.canUpload === true,
      canDelete: user.canDelete == 1 || user.canDelete === true,
      canDownload: user.canDownload == 1 || user.canDownload === true
    };
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
    logActivity(user.id, 'login', 'User logged in');
    res.json({ token, user: payload });
  });
});

// --- USER MANAGEMENT (Admin Only) ---
app.get('/api/users', authenticate, authorizeAdmin, (req, res) => {
  db.all("SELECT id, username, role, canUpload, canDelete, canDownload FROM users", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/users', authenticate, authorizeAdmin, async (req, res) => {
  const { username, password, role, canUpload, canDelete, canDownload } = req.body;
  try {
    const hash = await bcrypt.hash(password, 10);
    db.run(
      "INSERT INTO users (id, username, password, role, canUpload, canDelete, canDownload) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [uuidv4(), username, hash, role, canUpload ? 1 : 0, canDelete ? 1 : 0, canDownload ? 1 : 0],
      function (err) {
        if (err) {
          console.error('User creation error:', err.message);
          if (err.message.includes('UNIQUE constraint failed: users.username')) {
            return res.status(400).json({ error: 'Username is already taken' });
          }
          return res.status(500).json({ error: `Database Error: ${err.message}` });
        }
        logActivity(req.user.id, 'create_user', `Created user ${username}`);
        io.emit('users_update');
        res.json({ message: 'User created' });
      }
    );
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/users/:id', authenticate, authorizeAdmin, async (req, res) => {
  const { username, password, role, canUpload, canDelete, canDownload } = req.body;

  try {
    // If we're changing the username, check if it's already taken by someone else
    if (username) {
      const existing = await new Promise((resolve) => {
        db.get("SELECT id FROM users WHERE username = ? AND id != ?", [username, req.params.id], (err, row) => resolve(row));
      });
      if (existing) return res.status(400).json({ error: 'Username is already taken' });
    }

    let query;
    let params;

    if (password) {
      const hash = await bcrypt.hash(password, 10);
      query = "UPDATE users SET username = ?, password = ?, role = ?, canUpload = ?, canDelete = ?, canDownload = ? WHERE id = ?";
      params = [username, hash, role, canUpload ? 1 : 0, canDelete ? 1 : 0, canDownload ? 1 : 0, req.params.id];
    } else {
      query = "UPDATE users SET username = ?, role = ?, canUpload = ?, canDelete = ?, canDownload = ? WHERE id = ?";
      params = [username, role, canUpload ? 1 : 0, canDelete ? 1 : 0, canDownload ? 1 : 0, req.params.id];
    }

    db.run(query, params, (err) => {
      if (err) {
        console.error('User update error:', err.message);
        if (err.message.includes('UNIQUE constraint failed: users.username')) {
          return res.status(400).json({ error: 'Username is already taken' });
        }
        return res.status(500).json({ error: `Database Error: ${err.message}` });
      }
      logActivity(req.user.id, 'update_user', `Updated user ${username || req.params.id}`);
      io.emit('users_update');
      res.json({ message: 'User updated successfully' });
    });
  } catch (err) {
    console.error('Update operation failed:', err);
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/users/:id', authenticate, authorizeAdmin, (req, res) => {
  db.run("DELETE FROM users WHERE id = ?", [req.params.id], (err) => {
    if (err) return res.status(500).json({ error: err.message });
    logActivity(req.user.id, 'delete_user', `Deleted user ${req.params.id}`);
    io.emit('users_update');
    res.json({ message: 'User deleted' });
  });
});


// --- FILE SYSTEM ROUTES ---

// Get files
app.get('/api/files', authenticate, async (req, res) => {
  try {
    const dirPath = resolveSafePath(req.query.path || '');
    if (!await fs.pathExists(dirPath)) {
      return res.status(404).json({ error: 'Directory not found' });
    }

    const items = await fs.readdir(dirPath);
    const result = (await Promise.all(items.map(async (item) => {
      try {
        const itemPath = path.join(dirPath, item);
        const stat = await fs.stat(itemPath);
        return {
          name: item,
          isDirectory: stat.isDirectory(),
          size: stat.size,
          modifiedAt: stat.mtime
        };
      } catch (err) {
        return null; // Skip files with permission errors
      }
    }))).filter(Boolean);
    res.json(result);
  } catch (err) {
    console.error('Directory listing error:', err.message);
    res.status(500).json({ error: `Failed to list directory: ${err.message}` });
  }
});

// Upload file
app.post('/api/files/upload', authenticate, (req, res) => {
  upload.array('files')(req, res, (err) => {
    if (err) {
      console.error('Multer Upload Error:', err);
      return res.status(500).json({ error: `Upload failed: ${err.message}. Ensure you have write permissions to the destination.` });
    }
    
    const canUpload = req.user.canUpload !== undefined ? (req.user.canUpload == 1 || req.user.canUpload === true) : req.user.role === 'admin';
    if (!canUpload) return res.status(403).json({ error: 'Forbidden: No upload permission' });
    
    logActivity(req.user.id, 'upload', `Uploaded ${req.files?.length || 0} file(s) to ${req.body.path || '/'}`);
    io.emit('file_update');
    res.json({ message: 'Files uploaded successfully' });
  });
});

// Download file
app.get('/api/files/download', (req, res) => {
  const token = req.query.token;
  if (!token) return res.status(401).send('Unauthorized');

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const canDownload = decoded.canDownload !== undefined ? (decoded.canDownload == 1 || decoded.canDownload === true) : decoded.role === 'admin';
    if (!canDownload) return res.status(403).send('Forbidden: No download permission');

    const filePath = resolveSafePath(req.query.path);
    res.download(filePath, (err) => {
      if (err && !res.headersSent) {
        res.status(403).send('Access denied or file not found');
      }
    });
  } catch (e) {
    res.status(403).send('Invalid token');
  }
});

// Create folder
app.post('/api/files/folder', authenticate, async (req, res) => {
  const canUpload = req.user.canUpload !== undefined ? (req.user.canUpload == 1 || req.user.canUpload === true) : req.user.role === 'admin';
  if (!canUpload) return res.status(403).json({ error: 'Forbidden: No upload/create permission' });
  try {
    const targetPath = resolveSafePath(path.join(req.body.path || '', req.body.name));
    const normalizedTarget = path.normalize(targetPath).toLowerCase();
    const normalizedRoot = path.normalize(ROOT_DIR).toLowerCase();

    if (normalizedTarget !== normalizedRoot && normalizedTarget !== 'c:\\' && normalizedTarget !== 'c:') {
      await fs.ensureDir(targetPath);
    }
    logActivity(req.user.id, 'create_folder', `Created folder: ${req.body.name}`);
    io.emit('file_update');
    res.json({ message: 'Folder created' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rename/Move file
app.put('/api/files/move', authenticate, async (req, res) => {
  const canUpload = req.user.canUpload !== undefined ? (req.user.canUpload == 1 || req.user.canUpload === true) : req.user.role === 'admin';
  const canDelete = req.user.canDelete !== undefined ? (req.user.canDelete == 1 || req.user.canDelete === true) : req.user.role === 'admin';
  if (!canUpload || !canDelete) return res.status(403).json({ error: 'Forbidden: Need upload and delete permissions to move/rename' });
  try {
    const oldPath = resolveSafePath(req.body.oldPath);
    const newPath = resolveSafePath(req.body.newPath);
    await fs.move(oldPath, newPath, { overwrite: true });
    logActivity(req.user.id, 'move_rename', `Moved/Renamed ${req.body.oldPath} to ${req.body.newPath}`);
    io.emit('file_update');
    res.json({ message: 'File moved/renamed' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete file/folder
app.delete('/api/files', authenticate, async (req, res) => {
  const canDelete = req.user.canDelete !== undefined ? (req.user.canDelete == 1 || req.user.canDelete === true) : req.user.role === 'admin';
  if (!canDelete) return res.status(403).json({ error: 'Forbidden: No delete permission' });
  try {
    const targetPath = resolveSafePath(req.query.path);
    await fs.remove(targetPath);
    logActivity(req.user.id, 'delete', `Deleted ${req.query.path}`);
    io.emit('file_update');
    res.json({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Power controls
app.post('/api/system/power', authenticate, authorizeAdmin, (req, res) => {
  const { action } = req.body;
  logActivity(req.user.id, 'power_command', `Executed ${action} protocol`);

  switch (action) {
    case 'lock':
      exec('rundll32.exe user32.dll,LockWorkStation');
      break;
    case 'sleep':
      exec('rundll32.exe powrprof.dll,SetSuspendState 0,1,0');
      break;
    case 'restart':
      exec('shutdown /r /t 5');
      break;
    case 'shutdown':
      exec('shutdown /s /t 5');
      break;
    default:
      return res.status(400).json({ error: 'Invalid action' });
  }
  res.json({ message: `Executing ${action}...` });
});

// Screenshot capture
app.get('/api/system/screenshot', authenticate, authorizeAdmin, async (req, res) => {
  try {
    const img = await screenshot({ format: 'jpg' });
    logActivity(req.user.id, 'screenshot', 'Captured remote screen');
    res.set('Content-Type', 'image/jpeg');
    res.send(img);
  } catch (err) {
    console.error('Screenshot error:', err);
    res.status(500).json({ error: 'Failed to capture screenshot' });
  }
});

// --- SYSTEM & LOGS ---
app.get('/api/system', authenticate, authorizeAdmin, async (req, res) => {
  try {
    const cpu = await si.currentLoad();
    const mem = await si.mem();
    const osInfo = await si.osInfo();
    const disk = await si.fsSize();
    res.json({
      cpu: cpu.currentLoad,
      memory: { used: mem.active, total: mem.total },
      os: osInfo.distro,
      disk: disk[0] ? { used: disk[0].used, size: disk[0].size } : null
    });
  } catch (e) {
    res.status(500).json({ error: 'Failed to read system info' });
  }
});

app.get('/api/logs', authenticate, authorizeAdmin, (req, res) => {
  db.all("SELECT activity_logs.*, users.username FROM activity_logs LEFT JOIN users ON activity_logs.userId = users.id ORDER BY timestamp DESC LIMIT 50", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Preview files
app.get('/api/files/preview', (req, res) => {
  const token = req.query.token;
  if (!token) return res.status(401).send('Unauthorized');

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const canDownload = decoded.canDownload !== undefined ? (decoded.canDownload == 1 || decoded.canDownload === true) : decoded.role === 'admin';
    if (!canDownload) return res.status(403).send('Forbidden: No download permission');

    const filePath = resolveSafePath(req.query.path);
    res.sendFile(filePath, (err) => {
      if (err && !res.headersSent) {
        res.status(403).send('Access denied or file not found');
      }
    });
  } catch (e) {
    res.status(403).send('Invalid token');
  }
});

// --- PROCESS MANAGEMENT ---
app.get('/api/system/processes', authenticate, authorizeAdmin, async (req, res) => {
  try {
    const processes = await si.processes();
    res.json(processes.list.map(p => ({
      pid: p.pid,
      name: p.name,
      cpu: p.cpu,
      mem: p.mem,
      user: p.user
    })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch processes' });
  }
});

app.post('/api/system/processes/kill', authenticate, authorizeAdmin, (req, res) => {
  const { pid } = req.body;
  exec(`taskkill /F /PID ${pid}`, (err) => {
    if (err) return res.status(500).json({ error: `Failed to kill process: ${err.message}` });
    logActivity(req.user.id, 'kill_process', `Terminated PID ${pid}`);
    res.json({ message: 'Process terminated' });
  });
});

// --- AI COMMAND ASSISTANT ---
const AI_COMMANDS = {
  'clean temp files': [
    'del /q /s %temp%\\*',
    'del /q /s C:\\Windows\\Temp\\*',
    'echo Temp files cleared.'
  ],
  'system info': [
    'systeminfo',
    'wmic logicaldisk get size,freespace,caption'
  ],
  'flush dns': [
    'ipconfig /flushdns',
    'echo DNS cache flushed.'
  ],
  'list connections': [
    'netstat -an',
  ],
  'check disk': [
    'chkdsk C:',
  ],
  'ip configuration': [
    'ipconfig /all'
  ],
  'uptime': [
    'net statistics workstation'
  ]
};

app.post('/api/ai/execute', authenticate, authorizeAdmin, (req, res) => {
  const { command } = req.body;
  if (!command) return res.status(400).json({ error: 'Command input is empty.' });
  
  const normalized = command.toLowerCase().trim();
  
  // Try to find a match or partial match
  let matchedKey = Object.keys(AI_COMMANDS).find(key => 
    normalized.includes(key) || key.includes(normalized)
  );

  if (matchedKey) {
    const steps = AI_COMMANDS[matchedKey];
    logActivity(req.user.id, 'ai_command', `Executed sequence: ${matchedKey}`);
    
    const fullCommand = steps.join(' && ');
    exec(fullCommand, (err, stdout, stderr) => {
      const output = stdout || stderr || (err ? err.message : 'No output');
      res.json({ 
        message: err ? `AI Protocol [${matchedKey}] encountered an issue.` : `AI Protocol [${matchedKey}] executed successfully.`,
        output: output,
        steps 
      });
    });
  } else {
    res.status(400).json({ 
      error: 'Command not recognized. Please check available system protocols.',
      suggestions: Object.keys(AI_COMMANDS)
    });
  }
});

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  socket.on('terminal_command', (command) => {
    const child = spawn('cmd.exe', ['/c', command]);
    child.stdout.on('data', (data) => socket.emit('terminal_output', data.toString()));
    child.stderr.on('data', (data) => socket.emit('terminal_output', `ERROR: ${data.toString()}`));
    child.on('close', (code) => socket.emit('terminal_output', `\nProcess exited with code ${code}\n`));
  });

  // --- LIVE SCREEN STREAMING ---
  let screenStreamInterval = null;

  socket.on('start_screen_stream', async () => {
    if (screenStreamInterval) clearTimeout(screenStreamInterval);
    
    // Send initial resolution info
    try {
      const graphics = await si.graphics();
      const primary = graphics.displays.find(d => d.main) || graphics.displays[0];
      socket.emit('screen_init', {
        width: primary?.resolutionX || 1280,
        height: primary?.resolutionY || 800
      });
    } catch (err) {
      socket.emit('screen_init', { width: 1280, height: 800 });
    }

    const captureLoop = async () => {
      if (!socket.connected) return;
      try {
        const img = await screenshot({ format: 'jpg' });
        socket.emit('screen_frame', img);
        // console.log(`Frame sent: ${img.length} bytes`); // Log for debugging
        screenStreamInterval = setTimeout(captureLoop, 60); 
      } catch (err) {
        console.error('Capture error:', err);
        screenStreamInterval = setTimeout(captureLoop, 500);
      }
    };
    captureLoop();
  });

  socket.on('stop_screen_stream', () => {
    if (screenStreamInterval) {
      clearTimeout(screenStreamInterval);
      screenStreamInterval = null;
    }
  });

  // --- PERSISTENT POWERSHELL FOR INPUTS ---
  let ps;
  const startPS = () => {
    try {
      ps = spawn('powershell.exe', ['-NoExit', '-Command', '-'], { shell: true });
      ps.stdin.write(`
        $ErrorActionPreference = 'SilentlyContinue';
        Add-Type -AssemblyName System.Windows.Forms, System.Drawing;
        $sig = '[DllImport("user32.dll")] public static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);'
        if (-not ([System.Management.Automation.PSTypeName]'Win32Functions.Win32Mouse').Type) {
          Add-Type -MemberDefinition $sig -Name Win32Mouse -Namespace Win32Functions
        }
      \n`);
      ps.on('error', (err) => console.error('PS Process Error:', err));
      ps.stderr.on('data', (data) => {
        const errStr = data.toString();
        if (!errStr.includes('already exists')) console.error('PS Stderr:', errStr);
      });
      ps.on('exit', (code) => {
        console.log(`PS Process exited with code ${code}, restarting...`);
        if (socket.connected) setTimeout(startPS, 1000); // Wait 1s before restart
      });
    } catch (e) {
      console.error('Failed to start PS:', e);
    }
  };
  startPS();

  socket.on('remote_input', (data) => {
    const { type, x, y, button, key } = data;
    
    if (type === 'mousemove' && !isNaN(x) && !isNaN(y)) {
      ps.stdin.write(`[Windows.Forms.Cursor]::Position = New-Object Drawing.Point(${x}, ${y})\n`);
    } else if (type === 'mousedown') {
      const flag = button === 2 ? '0x0008' : '0x0002';
      ps.stdin.write(`[Win32Functions.Win32Mouse]::mouse_event(${flag}, 0, 0, 0, 0)\n`);
    } else if (type === 'mouseup') {
      const flag = button === 2 ? '0x0010' : '0x0004';
      ps.stdin.write(`[Win32Functions.Win32Mouse]::mouse_event(${flag}, 0, 0, 0, 0)\n`);
    } else if (type === 'doubleclick') {
      const flagDown = button === 2 ? '0x0008' : '0x0002';
      const flagUp = button === 2 ? '0x0010' : '0x0004';
      // Execute double click sequence in a single PS line for precision
      ps.stdin.write(`[Win32Functions.Win32Mouse]::mouse_event(${flagDown}, 0, 0, 0, 0); [Win32Functions.Win32Mouse]::mouse_event(${flagUp}, 0, 0, 0, 0); [Win32Functions.Win32Mouse]::mouse_event(${flagDown}, 0, 0, 0, 0); [Win32Functions.Win32Mouse]::mouse_event(${flagUp}, 0, 0, 0, 0);\n`);
    } else if (type === 'keydown') {
      // Handle special keys or strings
      if (key.length === 1) {
        // Regular character
        const escaped = key.replace(/'/g, "''");
        ps.stdin.write(`[System.Windows.Forms.SendKeys]::SendWait('${escaped}')\n`);
      } else {
        // Special keys like Enter, Backspace, etc.
        const specialKeys = {
          'Enter': '{ENTER}',
          'Backspace': '{BACKSPACE}',
          'Tab': '{TAB}',
          'Escape': '{ESC}',
          'ArrowUp': '{UP}',
          'ArrowDown': '{DOWN}',
          'ArrowLeft': '{LEFT}',
          'ArrowRight': '{RIGHT}',
          'Delete': '{DEL}',
          'Home': '{HOME}',
          'End': '{END}',
          'PageUp': '{PGUP}',
          'PageDown': '{PGDN}'
        };
        const mapped = specialKeys[key] || '';
        if (mapped) {
          ps.stdin.write(`[System.Windows.Forms.SendKeys]::SendWait('${mapped}')\n`);
        }
      }
    }
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    if (screenStreamInterval) {
      clearInterval(screenStreamInterval);
      screenStreamInterval = null;
    }
    ps.kill();
  });
});

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('SYSTEM_ERROR:', err.message);
  if (!res.headersSent) {
    res.status(500).json({ error: 'Internal system error occurred.' });
  }
});
