const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs-extra');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');

const dbPath = process.env.DB_PATH || path.join(__dirname, 'database.sqlite');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE,
      password TEXT,
      role TEXT,
      canUpload BOOLEAN DEFAULT 1,
      canDelete BOOLEAN DEFAULT 1,
      canDownload BOOLEAN DEFAULT 1
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS activity_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT,
      action TEXT,
      details TEXT,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS share_links (
      id TEXT PRIMARY KEY,
      filePath TEXT,
      password TEXT,
      expiresAt DATETIME,
      createdBy TEXT
    )
  `);

  // Create default admin if not exists
  db.get("SELECT * FROM users WHERE username = 'admin'", async (err, row) => {
    if (!row) {
      const hash = await bcrypt.hash('admin123', 10);
      db.run("INSERT INTO users (id, username, password, role, canUpload, canDelete, canDownload) VALUES (?, ?, ?, ?, 1, 1, 1)",
        [uuidv4(), 'admin', hash, 'admin']);
      console.log('Default admin created. Username: admin, Password: admin123');
    }
  });
});

module.exports = db;
