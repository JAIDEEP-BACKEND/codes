import { useState } from 'react';
import { Shield, Key, User as UserIcon, Terminal } from 'lucide-react';
import { motion } from 'framer-motion';
import api from '../api';

export default function Login({ setToken }: { setToken: (t: string) => void }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');
    try {
      const res = await api.post('/auth/login', { username, password });
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('user', JSON.stringify(res.data.user));
      setToken(res.data.token);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Authentication Failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-cyber-bg p-6 relative overflow-hidden">
      {/* Dynamic Background */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:32px_32px]"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyber-primary/5 blur-[120px] rounded-full pointer-events-none"></div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full glass-heavy rounded-[2.5rem] border-white/5 p-8 lg:p-10 relative z-10 shadow-2xl"
      >
        <div className="flex flex-col items-center mb-10">
          <div className="p-5 bg-black/50 border border-cyber-primary/30 rounded-3xl mb-6 shadow-[0_0_30px_rgba(0,255,204,0.15)] relative group">
            <div className="absolute inset-0 bg-cyber-primary/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <Shield className="w-10 h-10 text-cyber-primary relative z-10" />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-[0.3em] font-mono">NEXUS.ID</h1>
          <p className="text-[10px] text-cyber-primary font-mono mt-2 tracking-[0.2em] uppercase opacity-50">Secure Authentication Protocol</p>
        </div>

        {error && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-2xl text-[10px] font-mono text-center uppercase tracking-widest"
          >
            [Access_Denied]: {error}
          </motion.div>
        )}

        <form onSubmit={handleLogin} className="space-y-5">
          <div className="relative">
            <UserIcon className="w-4 h-4 text-gray-600 absolute left-4 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-black/40 border border-white/5 rounded-2xl pl-12 pr-4 py-4 text-white focus:border-cyber-primary/50 outline-none transition-all font-mono text-sm placeholder:text-gray-700"
              placeholder="IDENTITY_TAG"
              required
            />
          </div>
          
          <div className="relative">
            <Key className="w-4 h-4 text-gray-600 absolute left-4 top-1/2 -translate-y-1/2" />
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-black/40 border border-white/5 rounded-2xl pl-12 pr-4 py-4 text-white focus:border-cyber-primary/50 outline-none transition-all font-mono text-sm placeholder:text-gray-700"
              placeholder="ACCESS_KEY"
              required
            />
          </div>

          <button 
            disabled={isSubmitting}
            type="submit"
            className="w-full bg-cyber-primary text-black font-mono font-black py-4 rounded-2xl tracking-[0.2em] transition-all hover:brightness-110 active:scale-[0.98] shadow-[0_10px_20px_rgba(0,255,204,0.2)] disabled:opacity-50 mt-4"
          >
            {isSubmitting ? 'INITIALIZING...' : 'AUTHORIZE'}
          </button>
        </form>

        <div className="mt-10 flex justify-center space-x-6">
          <div className="flex items-center space-x-2">
            <Terminal className="w-3 h-3 text-gray-700" />
            <span className="text-[9px] font-mono text-gray-700 tracking-tighter uppercase">v1.0.0-SECURE</span>
          </div>
          <div className="w-1.5 h-1.5 rounded-full bg-cyber-primary/20"></div>
          <span className="text-[9px] font-mono text-gray-700 tracking-tighter uppercase">AES_256_ACTIVE</span>
        </div>
      </motion.div>
    </div>
  );
}
