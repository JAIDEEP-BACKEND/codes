import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { io } from 'socket.io-client';
import FileList from '../components/FileList';
import ActivityLog from '../components/ActivityLog';
import SystemStats from '../components/SystemStats';
import UserManagement from '../components/UserManagement';
import Terminal from '../components/Terminal';
import RemoteDesktop from '../components/RemoteDesktop';
import ProcessManager from '../components/ProcessManager';
import AIAssistant from '../components/AIAssistant';
import {
  LogOut,
  Folder,
  HardDrive,
  Terminal as TerminalIcon,
  Shield,
  Activity,
  Menu,
  X as CloseIcon,
  Monitor,
  Cpu,
  Bot
} from 'lucide-react';

const socket = io(`http://${window.location.hostname}:8080`);

export default function Dashboard({ setToken }: { setToken: (t: string | null) => void }) {
  const [currentPath, setCurrentPath] = useState('');
  const [activeTab, setActiveTab] = useState<'files' | 'logs' | 'system' | 'terminal' | 'users' | 'remote' | 'processes' | 'ai'>('files');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
  };

  const menuItems = [
    { id: 'files', label: 'Files', icon: Folder, adminOnly: false },
    { id: 'remote', label: 'Remote Desktop', icon: Monitor, adminOnly: true },
    { id: 'ai', label: 'AI Assistant', icon: Bot, adminOnly: true },
    { id: 'processes', label: 'Processes', icon: Cpu, adminOnly: true },
    { id: 'terminal', label: 'Terminal', icon: TerminalIcon, adminOnly: true },
    { id: 'system', label: 'System Stats', icon: HardDrive, adminOnly: true },
    { id: 'logs', label: 'Activity Logs', icon: Activity, adminOnly: true },
    { id: 'users', label: 'User Management', icon: Shield, adminOnly: true },
  ];

  const handleTabChange = (id: any) => {
    setActiveTab(id);
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="h-screen flex bg-cyber-bg overflow-hidden relative selection:bg-cyber-primary/30">
      {/* Background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none"></div>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-[#0a0a0a]/80 backdrop-blur-md border-b border-white/5 flex items-center justify-between px-6 z-50">
        <div className="flex items-center space-x-3">
          <Shield className="w-6 h-6 text-cyber-primary shadow-[0_0_10px_#00ffcc]" />
          <h1 className="font-mono font-bold text-white tracking-widest text-sm uppercase">Nexus.FS</h1>
        </div>
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 glass rounded-lg text-cyber-primary"
        >
          {isMobileMenuOpen ? <CloseIcon className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Sidebar / Mobile Menu Overlay */}
      <AnimatePresence>
        {(isMobileMenuOpen || window.innerWidth >= 1024) && (
          <motion.div
            initial={window.innerWidth < 1024 ? { x: '-100%' } : { x: 0 }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className={`fixed inset-0 lg:relative lg:flex w-full lg:w-72 bg-[#050505] lg:bg-cyber-surface border-r border-white/5 flex-col z-[60]`}
          >
            <div className="p-8 pt-20 lg:pt-8 border-b border-white/5">
              <div className="hidden lg:flex items-center space-x-3 mb-6">
                <Shield className="w-8 h-8 text-cyber-primary" />
                <div>
                  <h1 className="font-mono font-bold text-white tracking-widest uppercase">Nexus.FS</h1>
                  <p className="text-[10px] text-cyber-primary font-mono opacity-50 tracking-tighter">System Console v1.0</p>
                </div>
              </div>
              <div className="glass p-4 rounded-2xl border-white/5 flex items-center space-x-4">
                <div className="w-3 h-3 rounded-full bg-cyber-primary animate-pulse shadow-[0_0_8px_#00ffcc]"></div>
                <div className="font-mono text-xs overflow-hidden">
                  <p className="text-gray-400 truncate">User: <span className="text-white font-bold">{user.username}</span></p>
                  <p className="text-gray-400 truncate">Role: <span className="text-cyber-secondary">{user.role}</span></p>
                </div>
              </div>
            </div>

            <nav className="flex-1 p-6 space-y-2 overflow-y-auto">
              {menuItems.map((item) => {
                if (item.adminOnly && user.role !== 'admin') return null;
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleTabChange(item.id)}
                    className={`w-full flex items-center justify-between px-6 py-4.5 rounded-2xl transition-all font-mono text-sm group border ${activeTab === item.id ? 'bg-cyber-primary/10 text-cyber-primary border-cyber-primary/30 shadow-[0_0_25px_rgba(0,255,204,0.08)]' : 'text-gray-400 hover:bg-white/[0.04] hover:text-white border-transparent'}`}
                  >
                    <div className="flex items-center space-x-4">
                      <Icon className={`w-5 h-5 transition-colors ${activeTab === item.id ? 'text-cyber-primary' : 'text-gray-600 group-hover:text-gray-400'}`} />
                      <span className="tracking-[0.15em] uppercase font-bold">{item.label}</span>
                    </div>
                    {activeTab === item.id && (
                      <motion.div
                        layoutId="active-pill"
                        className="w-1.5 h-1.5 rounded-full bg-cyber-primary shadow-[0_0_10px_#00ffcc]"
                      />
                    )}
                  </button>
                );
              })}
            </nav>

            <div className="p-6 border-t border-white/5">
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center space-x-3 px-6 py-4 rounded-2xl bg-red-500/5 text-red-500 border border-red-500/10 hover:bg-red-500/10 active:scale-95 transition-all font-mono text-xs font-bold tracking-widest"
              >
                <LogOut className="w-4 h-4" />
                <span>LOGOUT</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col relative z-10 pt-16 lg:pt-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="h-full flex flex-col"
          >
            {activeTab === 'files' && <FileList currentPath={currentPath} setCurrentPath={setCurrentPath} socket={socket} />}
            {activeTab === 'remote' && user.role === 'admin' && <RemoteDesktop socket={socket} />}
            {activeTab === 'ai' && user.role === 'admin' && <AIAssistant />}
            {activeTab === 'processes' && user.role === 'admin' && <ProcessManager />}
            {activeTab === 'logs' && user.role === 'admin' && <ActivityLog socket={socket} />}
            {activeTab === 'system' && user.role === 'admin' && <SystemStats />}
            {activeTab === 'terminal' && user.role === 'admin' && <Terminal socket={socket} />}
            {activeTab === 'users' && user.role === 'admin' && <UserManagement socket={socket} />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
