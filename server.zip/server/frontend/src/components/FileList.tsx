import { useState, useEffect, useRef } from 'react';
import { 
  Folder, File, Upload, Plus, Download, Trash2, 
  ChevronRight, HardDrive, Search, X, FileText, 
  ImageIcon, Music, Video, FileArchive, MoreVertical, 
  Eye, Check, ChevronLeft
} from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import api from '../api';

export default function FileList({ currentPath, setCurrentPath, socket }: any) {
  const [files, setFiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  
  // Mobile Action Sheet State
  const [activeFile, setActiveFile] = useState<any>(null);

  const rawUser = JSON.parse(localStorage.getItem('user') || '{}');
  const user = {
    ...rawUser,
    canUpload: rawUser.canUpload == 1 || rawUser.canUpload === true || rawUser.role === 'admin',
    canDelete: rawUser.canDelete == 1 || rawUser.canDelete === true || rawUser.role === 'admin',
    canDownload: rawUser.canDownload == 1 || rawUser.canDownload === true || rawUser.role === 'admin'
  };
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchFiles = async () => {
    try {
      const res = await api.get(`/files?path=${encodeURIComponent(currentPath)}`);
      setFiles(res.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    fetchFiles();
    socket.on('file_update', fetchFiles);
    return () => socket.off('file_update', fetchFiles);
  }, [currentPath]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.length) return;
    const formData = new FormData();
    formData.append('path', currentPath);
    Array.from(e.target.files).forEach(f => formData.append('files', f));

    try {
      await api.post('/files/upload', formData, {
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / (progressEvent.total || 1));
          setUploadProgress(percentCompleted);
        }
      });
      setTimeout(() => setUploadProgress(0), 1000);
    } catch (e: any) {
      console.error(e);
      setUploadProgress(0);
      const msg = e.response?.data?.error || 'Upload failed. Check your network or permissions.';
      alert(msg);
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName) return;
    try {
      await api.post('/files/folder', { path: currentPath, name: newFolderName });
      setShowNewFolder(false);
      setNewFolderName('');
    } catch (e) {
      console.error(e);
      alert('Failed to create folder.');
    }
  };

  const handleDelete = async (filename: string) => {
    if (!confirm(`Permanently delete ${filename}?`)) return;
    const targetPath = currentPath ? `${currentPath}/${filename}` : filename;
    try {
      await api.delete(`/files?path=${encodeURIComponent(targetPath)}`);
      setActiveFile(null);
    } catch (e) {
      console.error(e);
      alert('Delete failed.');
    }
  };

  const handleDownload = (filename: string) => {
    const targetPath = currentPath ? `${currentPath}/${filename}` : filename;
    const token = localStorage.getItem('token');
    window.open(`http://${window.location.hostname}:8080/api/files/download?path=${encodeURIComponent(targetPath)}&token=${token}`, '_blank');
    setActiveFile(null);
  };

  const handlePreview = (filename: string) => {
    if (!user.canDownload) return;
    const targetPath = currentPath ? `${currentPath}/${filename}` : filename;
    const token = localStorage.getItem('token');
    window.open(`http://${window.location.hostname}:8080/api/files/preview?path=${encodeURIComponent(targetPath)}&token=${token}`, '_blank');
    setActiveFile(null);
  };

  const getFileIcon = (name: string, isDirectory: boolean, size = "w-5 h-5") => {
    if (isDirectory) return <Folder className={`${size} text-cyber-primary fill-cyber-primary/10`} />;
    const ext = name.split('.').pop()?.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext!)) return <ImageIcon className={`${size} text-purple-400`} />;
    if (['mp4', 'mkv', 'avi', 'mov'].includes(ext!)) return <Video className={`${size} text-red-400`} />;
    if (['mp3', 'wav', 'ogg'].includes(ext!)) return <Music className={`${size} text-pink-400`} />;
    if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext!)) return <FileArchive className={`${size} text-orange-400`} />;
    if (['txt', 'md', 'json', 'js', 'ts', 'html', 'css'].includes(ext!)) return <FileText className={`${size} text-blue-400`} />;
    return <File className={`${size} text-gray-400`} />;
  };

  const filteredFiles = files.filter(f => f.name.toLowerCase().includes(search.toLowerCase()));

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="h-full flex flex-col p-4 md:p-6 lg:p-8 bg-cyber-bg relative overflow-hidden">
      {/* Dynamic Header */}
      <div className="flex flex-col space-y-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 overflow-hidden flex-1 mr-4">
            <button 
              onClick={() => setCurrentPath('')}
              className="p-2 glass rounded-lg text-cyber-primary active:scale-95 transition-all"
            >
              <HardDrive className="w-5 h-5" />
            </button>
            <div className="flex items-center space-x-1 font-mono text-[10px] overflow-x-auto no-scrollbar whitespace-nowrap text-gray-500">
              {currentPath.split('/').filter(Boolean).map((part, i, arr) => (
                <div key={i} className="flex items-center">
                  <ChevronRight className="w-3 h-3 text-gray-700" />
                  <button 
                    onClick={() => setCurrentPath(arr.slice(0, i + 1).join('/'))}
                    className="px-1.5 py-1 hover:text-cyber-primary transition-colors"
                  >
                    {part}
                  </button>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-2 shrink-0">
            {user.canUpload && (
              <>
                <button onClick={() => setShowNewFolder(true)} className="p-2.5 glass rounded-xl text-gray-400 active:scale-90 transition-all"><Plus className="w-5 h-5" /></button>
                <button onClick={() => fileInputRef.current?.click()} className="p-2.5 bg-cyber-primary/10 border border-cyber-primary/30 rounded-xl text-cyber-primary active:scale-90 transition-all shadow-[0_0_15px_rgba(0,255,204,0.2)]"><Upload className="w-5 h-5" /></button>
              </>
            )}
          </div>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-gray-600 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Search files..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-10 pr-4 py-3 text-sm text-white focus:border-cyber-primary/50 outline-none font-mono transition-all"
          />
        </div>
      </div>

      <AnimatePresence>
        {uploadProgress > 0 && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0 }} className="mb-4 glass p-3 rounded-xl border-cyber-primary/20">
            <div className="flex justify-between text-[10px] font-mono text-cyber-primary mb-1.5 uppercase tracking-widest">
              <span className="animate-pulse">Uploading</span>
              <span>{uploadProgress}%</span>
            </div>
            <div className="w-full bg-black/40 rounded-full h-1 overflow-hidden">
              <motion.div className="bg-cyber-primary h-full shadow-[0_0_10px_#00ffcc]" initial={{ width: 0 }} animate={{ width: `${uploadProgress}%` }} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showNewFolder && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mb-4 glass p-3 rounded-xl border-cyber-primary/30 flex items-center space-x-3">
            <input autoFocus type="text" placeholder="Folder name..." value={newFolderName} onChange={e => setNewFolderName(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleCreateFolder()} className="bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-cyber-primary font-mono flex-1" />
            <button onClick={handleCreateFolder} className="p-2 bg-cyber-primary text-black rounded-lg active:scale-95 transition-all"><Check className="w-5 h-5" /></button>
            <button onClick={() => setShowNewFolder(false)} className="p-2 text-gray-500"><X className="w-5 h-5" /></button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Container */}
      <div className="flex-1 glass rounded-3xl border-white/5 overflow-hidden flex flex-col shadow-2xl">
        <div className="flex-1 overflow-y-auto custom-scrollbar p-2">
          {currentPath && (
            <div 
              onClick={() => {
                const parts = currentPath.split('/');
                parts.pop();
                setCurrentPath(parts.join('/'));
              }}
              className="flex items-center space-x-4 p-4 mb-1 hover:bg-white/5 rounded-2xl cursor-pointer active:scale-[0.98] transition-all"
            >
              <div className="p-2.5 rounded-xl bg-white/[0.03] text-gray-500"><ChevronLeft className="w-5 h-5" /></div>
              <span className="font-mono text-xs text-gray-500 uppercase tracking-widest">Parent Directory</span>
            </div>
          )}

          {loading ? (
            <div className="flex flex-col items-center justify-center h-64 space-y-4">
              <div className="w-12 h-12 border-2 border-cyber-primary/10 border-t-cyber-primary rounded-full animate-spin shadow-[0_0_15px_rgba(0,255,204,0.1)]"></div>
              <p className="font-mono text-[10px] text-cyber-primary animate-pulse tracking-[0.2em] uppercase">Loading Files</p>
            </div>
          ) : filteredFiles.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 opacity-20">
              <HardDrive className="w-16 h-16 mb-4 text-gray-500" />
              <p className="font-mono text-xs uppercase tracking-widest text-gray-500">Folder Empty</p>
            </div>
          ) : (
            filteredFiles.sort((a, b) => b.isDirectory - a.isDirectory || a.name.localeCompare(b.name)).map((file) => (
              <motion.div 
                key={file.name} 
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center justify-between p-4 mb-2 hover:bg-white/[0.04] active:bg-white/[0.08] rounded-2xl border border-transparent hover:border-white/5 transition-all group"
                onClick={(e) => {
                  const now = Date.now();
                  const timeDiff = now - (e.currentTarget as any).lastClickTime || 0;
                  (e.currentTarget as any).lastClickTime = now;

                  if (timeDiff > 0 && timeDiff < 300) {
                    // Double tap
                    if (file.isDirectory) {
                      setCurrentPath(currentPath ? `${currentPath}/${file.name}` : file.name);
                    } else {
                      handlePreview(file.name);
                    }
                  } else {
                    // Single tap - wait a bit to see if it's a double tap
                    setTimeout(() => {
                      if (Date.now() - (e.currentTarget as any).lastClickTime >= 300) {
                        if (file.isDirectory) {
                          setCurrentPath(currentPath ? `${currentPath}/${file.name}` : file.name);
                        } else {
                          setActiveFile(file);
                        }
                      }
                    }, 300);
                  }
                }}
              >
                <div className="flex items-center space-x-4 flex-1 min-w-0">
                  <div className="p-3 rounded-2xl bg-black/40 group-hover:bg-black/60 transition-colors shadow-inner">
                    {getFileIcon(file.name, file.isDirectory)}
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="font-mono text-sm text-gray-200 truncate font-semibold tracking-tight">{file.name}</span>
                    <div className="flex items-center space-x-2 mt-0.5">
                      <span className="font-mono text-[9px] text-gray-600 uppercase tracking-tighter">
                        {file.isDirectory ? 'Directory' : formatSize(file.size)}
                      </span>
                      <span className="w-1 h-1 rounded-full bg-gray-800"></span>
                      <span className="font-mono text-[9px] text-gray-600 tracking-tighter">
                        {format(new Date(file.modifiedAt), 'MMM dd, yyyy')}
                      </span>
                    </div>
                  </div>
                </div>
                {!file.isDirectory && (
                  <div className="p-2 rounded-lg group-hover:bg-cyber-primary/10 transition-all">
                    <MoreVertical className="w-4 h-4 text-gray-600 group-hover:text-cyber-primary" />
                  </div>
                )}
              </motion.div>
            ))
          )}
        </div>
      </div>

      {/* MOBILE ACTION SHEET (iOS/Android Style) */}
      <AnimatePresence>
        {activeFile && (
          <>
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveFile(null)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100]"
            />
            
            {/* Sheet */}
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-[101] bg-[#0a0a0a] border-t border-white/10 rounded-t-[2.5rem] p-6 pb-10 shadow-[0_-20px_40px_rgba(0,0,0,0.5)]"
            >
              {/* Handle */}
              <div className="w-12 h-1.5 bg-white/10 rounded-full mx-auto mb-8" />
              
              <div className="flex items-center space-x-5 mb-8 p-4 glass rounded-2xl border border-white/5">
                <div className="p-4 bg-black/50 rounded-2xl border border-white/5">
                  {getFileIcon(activeFile.name, false, "w-8 h-8")}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-mono text-lg text-white truncate font-bold">{activeFile.name}</h3>
                  <p className="font-mono text-[10px] text-gray-500 uppercase tracking-widest mt-1">
                    {formatSize(activeFile.size)} • {format(new Date(activeFile.modifiedAt), 'dd MMM yyyy')}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3">
                <button 
                  onClick={() => handlePreview(activeFile.name)}
                  className="flex items-center justify-between p-5 glass-hover rounded-2xl text-gray-300 hover:text-cyber-primary active:bg-cyber-primary/10 transition-all border border-white/[0.03]"
                >
                  <div className="flex items-center space-x-4">
                    <Eye className="w-5 h-5 text-cyber-primary" />
                    <span className="font-mono text-sm font-bold uppercase tracking-widest">Preview File</span>
                  </div>
                  <ChevronRight className="w-4 h-4 opacity-30" />
                </button>

                <button 
                  onClick={() => handleDownload(activeFile.name)}
                  className="flex items-center justify-between p-5 glass-hover rounded-2xl text-gray-300 hover:text-cyber-primary active:bg-cyber-primary/10 transition-all border border-white/[0.03]"
                >
                  <div className="flex items-center space-x-4">
                    <Download className="w-5 h-5 text-cyber-primary" />
                    <span className="font-mono text-sm font-bold uppercase tracking-widest">Download File</span>
                  </div>
                  <ChevronRight className="w-4 h-4 opacity-30" />
                </button>

                {user.canDelete && (
                  <button 
                    onClick={() => handleDelete(activeFile.name)}
                    className="flex items-center justify-between p-5 hover:bg-red-500/10 rounded-2xl text-gray-400 hover:text-red-400 active:bg-red-500/20 transition-all border border-white/[0.03] mt-2"
                  >
                    <div className="flex items-center space-x-4">
                      <Trash2 className="w-5 h-5 text-red-500" />
                      <span className="font-mono text-sm font-bold uppercase tracking-widest">Delete File</span>
                    </div>
                    <ChevronRight className="w-4 h-4 opacity-30" />
                  </button>
                )}
                
                <button 
                  onClick={() => setActiveFile(null)}
                  className="mt-4 p-5 glass text-gray-500 font-mono text-xs font-bold uppercase tracking-[0.3em] rounded-2xl active:scale-95 transition-all"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <input type="file" ref={fileInputRef} className="hidden" multiple onChange={handleUpload} />
    </div>
  );
}
