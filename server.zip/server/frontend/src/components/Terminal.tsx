import { useState, useEffect, useRef } from 'react';
import { Terminal as TerminalIcon, Send, Trash2, ChevronRight } from 'lucide-react';

export default function Terminal({ socket }: { socket: any }) {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState<string[]>(['Nexus.FS [Version 1.0.42]', 'C:\\Users\\Administrator> _']);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutput = (data: string) => {
      setOutput(prev => [...prev, data]);
    };

    socket.on('terminal_output', handleOutput);
    return () => socket.off('terminal_output', handleOutput);
  }, [socket]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [output]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setOutput(prev => [...prev, `> ${input}`]);
    socket.emit('terminal_command', input);
    setInput('');
  };

  const clearTerminal = () => {
    setOutput(['Terminal cleared.']);
  };

  return (
    <div className="h-full p-4 lg:p-8 flex flex-col bg-cyber-bg">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="p-3 glass rounded-2xl border-cyber-primary/30">
            <TerminalIcon className="w-6 h-6 text-cyber-primary" />
          </div>
          <div>
            <h2 className="text-xl font-mono text-white tracking-widest font-bold">Remote Terminal</h2>
            <p className="text-[10px] text-gray-500 font-mono tracking-tighter uppercase opacity-50">Direct System Access</p>
          </div>
        </div>
        <button
          onClick={clearTerminal}
          className="p-3 glass rounded-xl text-gray-500 hover:text-red-400 transition-colors"
        >
          <Trash2 className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 glass rounded-3xl border-white/5 overflow-hidden flex flex-col shadow-2xl relative">
        {/* Terminal Header */}
        <div className="bg-white/[0.02] border-b border-white/5 px-6 py-3 flex items-center space-x-2">
          <div className="w-2 h-2 rounded-full bg-red-500/40"></div>
          <div className="w-2 h-2 rounded-full bg-yellow-500/40"></div>
          <div className="w-2 h-2 rounded-full bg-green-500/40"></div>
          <span className="ml-4 font-mono text-[9px] text-gray-600 tracking-widest uppercase">Nexus Console</span>
        </div>

        {/* Output Area */}
        <div
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 font-mono text-xs md:text-sm custom-scrollbar bg-black/20"
        >
          {output.map((line, i) => (
            <div key={i} className="mb-1 whitespace-pre-wrap">
              {line.startsWith('>') ? (
                <span className="text-cyber-primary font-bold">{line}</span>
              ) : line.startsWith('ERROR:') ? (
                <span className="text-red-400">{line}</span>
              ) : (
                <span className="text-gray-300">{line}</span>
              )}
            </div>
          ))}
        </div>

        {/* Input Area */}
        <form
          onSubmit={handleSubmit}
          className="p-4 bg-white/[0.02] border-t border-white/5 flex items-center space-x-3"
        >
          <ChevronRight className="w-4 h-4 text-cyber-primary" />
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter command..."
            className="flex-1 bg-transparent border-none outline-none font-mono text-white placeholder:text-gray-700 text-sm"
            autoFocus
          />
          <button
            type="submit"
            className="p-2 text-cyber-primary hover:scale-110 transition-transform"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
