import { useState, useEffect } from 'react';
import { Activity, XCircle, RefreshCw, Cpu, Database } from 'lucide-react';
import api from '../api';
import { motion, AnimatePresence } from 'framer-motion';

interface Process {
  pid: number;
  name: string;
  cpu: number;
  mem: number;
  user: string;
}

export default function ProcessManager() {
  const [processes, setProcesses] = useState<Process[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchProcesses = async () => {
    setLoading(true);
    try {
      const res = await api.get('/system/processes');
      setProcesses(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const killProcess = async (pid: number) => {
    if (!confirm(`Are you sure you want to terminate PID ${pid}?`)) return;
    try {
      await api.post('/system/processes/kill', { pid });
      fetchProcesses();
    } catch (err) {
      alert('Failed to kill process');
    }
  };

  useEffect(() => {
    fetchProcesses();
    const interval = setInterval(fetchProcesses, 5000);
    return () => clearInterval(interval);
  }, []);

  const filtered = processes.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.pid.toString().includes(searchTerm)
  ).sort((a, b) => b.cpu - a.cpu);

  return (
    <div className="flex flex-col h-full bg-cyber-surface/30 backdrop-blur-md rounded-[2rem] border border-white/5 overflow-hidden">
      <div className="p-6 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyber-primary/10 rounded-lg">
            <Activity className="w-5 h-5 text-cyber-primary" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white tracking-wider uppercase font-mono">Process Manager</h2>
            <p className="text-[10px] text-gray-400 font-mono uppercase tracking-tighter">System Resource Monitor</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <input
            type="text"
            placeholder="Search processes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-black/40 border border-white/5 rounded-xl px-4 py-2 text-xs font-mono text-cyber-primary outline-none focus:border-cyber-primary/30 transition-all w-48"
          />
          <button
            onClick={fetchProcesses}
            className="p-2 hover:bg-white/5 rounded-xl transition-colors text-gray-400 hover:text-cyber-primary"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4 custom-scrollbar">
        {/* Desktop View Table */}
        <div className="hidden md:block">
          <table className="w-full text-left font-mono text-[11px]">
            <thead className="sticky top-0 bg-cyber-bg/80 backdrop-blur-sm text-gray-500 uppercase tracking-widest border-b border-white/5 z-10">
              <tr>
                <th className="py-3 px-4">PID</th>
                <th className="py-3 px-4">NAME</th>
                <th className="py-3 px-4">
                  <div className="flex items-center gap-1"><Cpu className="w-3 h-3" /> CPU</div>
                </th>
                <th className="py-3 px-4">
                  <div className="flex items-center gap-1"><Database className="w-3 h-3" /> MEMORY</div>
                </th>
                <th className="py-3 px-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {filtered.map((p) => (
                  <motion.tr
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    key={p.pid}
                    className="border-b border-white/5 hover:bg-white/5 transition-colors group"
                  >
                    <td className="py-3 px-4 text-gray-400">{p.pid}</td>
                    <td className="py-3 px-4 text-white font-bold">{p.name}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-white/5 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-cyber-primary transition-all duration-500 shadow-[0_0_8px_#00ffcc]"
                            style={{ width: `${Math.min(p.cpu * 2, 100)}%` }}
                          />
                        </div>
                        <span className={p.cpu > 50 ? 'text-red-400' : 'text-cyber-primary'}>{p.cpu.toFixed(1)}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-gray-400">{p.mem.toFixed(1)}%</span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => killProcess(p.pid)}
                        title="End Task"
                        className="opacity-0 group-hover:opacity-100 p-2 text-gray-500 hover:text-red-500 transition-all hover:bg-red-500/10 rounded-lg"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>

        {/* Mobile View Cards */}
        <div className="md:hidden space-y-3">
          <AnimatePresence>
            {filtered.map((p) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                key={p.pid}
                className="bg-white/5 border border-white/5 rounded-2xl p-4 space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <p className="text-white font-bold font-mono text-sm truncate max-w-[200px]">{p.name}</p>
                    <p className="text-[10px] text-gray-500 font-mono tracking-widest uppercase">PID: {p.pid}</p>
                  </div>
                  <button
                    onClick={() => killProcess(p.pid)}
                    className="p-2 text-red-500/50 hover:text-red-500 bg-red-500/5 rounded-xl border border-red-500/10"
                  >
                    <XCircle className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-[9px] text-gray-500 font-mono uppercase tracking-tighter">
                      <Cpu className="w-3 h-3 text-cyber-primary" /> CPU Load
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-cyber-primary shadow-[0_0_5px_#00ffcc]"
                          style={{ width: `${Math.min(p.cpu * 2, 100)}%` }}
                        />
                      </div>
                      <span className={`text-[10px] font-mono ${p.cpu > 50 ? 'text-red-400' : 'text-cyber-primary'}`}>{p.cpu.toFixed(1)}%</span>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-[9px] text-gray-500 font-mono uppercase tracking-tighter">
                      <Database className="w-3 h-3 text-cyber-secondary" /> MEMORY
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-cyber-secondary shadow-[0_0_5px_#ff0055]"
                          style={{ width: `${Math.min(p.mem * 2, 100)}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-mono text-gray-400">{p.mem.toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
