import { useState, useEffect, useRef } from 'react';
import { Monitor, Play, Square, MousePointer2, Keyboard, Fullscreen } from 'lucide-react';
import { Socket } from 'socket.io-client';

export default function RemoteDesktop({ socket }: { socket: Socket }) {
  const [isStreaming, setIsStreaming] = useState(false);
  const [frame, setFrame] = useState<string | null>(null);
  const [resolution, setResolution] = useState({ width: 1280, height: 800 });
  const [showKeyboard, setShowKeyboard] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    socket.on('screen_frame', (data: any) => {
      // data can be ArrayBuffer or Uint8Array/Buffer
      const blob = new Blob([data], { type: 'image/jpeg' });
      const url = URL.createObjectURL(blob);
      setFrame(prev => {
        if (prev) URL.revokeObjectURL(prev);
        return url;
      });
    });

    socket.on('screen_init', (res: { width: number, height: number }) => {
      setResolution(res);
    });

    return () => {
      socket.off('screen_frame');
      socket.off('screen_init');
      if (isStreaming) socket.emit('stop_screen_stream');
    };
  }, [socket, isStreaming]);

  const toggleStream = () => {
    if (isStreaming) {
      socket.emit('stop_screen_stream');
    } else {
      socket.emit('start_screen_stream');
    }
    setIsStreaming(!isStreaming);
  };

  const [isFirstFrame, setIsFirstFrame] = useState(true);
  const lastEmitTime = useRef<number>(0);

  const emitInput = (type: string, x: number, y: number, button: number = 0) => {
    if (type === 'mousemove') {
      const now = Date.now();
      if (now - lastEmitTime.current < 30) return;
      lastEmitTime.current = now;
    }

    if (!imageRef.current) return;
    const rect = imageRef.current.getBoundingClientRect();
    const scaleX = resolution.width / rect.width;
    const scaleY = resolution.height / rect.height;

    const rx = Math.round((x - rect.left) * scaleX);
    const ry = Math.round((y - rect.top) * scaleY);

    socket.emit('remote_input', { type, x: rx, y: ry, button });
  };

  const handleMouseEvent = (e: React.MouseEvent) => {
    if (!isStreaming) return;
    let type = '';
    if (e.type === 'mousemove') type = 'mousemove';
    if (e.type === 'mousedown') type = 'mousedown';
    if (e.type === 'mouseup') type = 'mouseup';
    if (type) emitInput(type, e.clientX, e.clientY, e.button);
  };

  const lastTouchTime = useRef<number>(0);
  const handleTouchEvent = (e: React.TouchEvent) => {
    if (!isStreaming || e.touches.length === 0) return;
    const touch = e.touches[0];
    const now = Date.now();
    let type = '';
    
    if (e.type === 'touchstart') {
      const timeDiff = now - lastTouchTime.current;
      type = timeDiff < 300 ? 'doubleclick' : 'mousedown';
      lastTouchTime.current = now;
      emitInput('mousemove', touch.clientX, touch.clientY);
    } else if (e.type === 'touchmove') {
      type = 'mousemove';
      e.preventDefault();
    } else if (e.type === 'touchend') {
      type = 'mouseup';
    }

    if (type) emitInput(type, touch.clientX, touch.clientY);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isStreaming) return;
    if (['Tab', 'Backspace'].includes(e.key)) e.preventDefault();
    socket.emit('remote_input', { type: 'keydown', key: e.key });
  };

  const handleHiddenInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    if (val.length > 0) {
      socket.emit('remote_input', { type: 'keydown', key: val.slice(-1) });
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  const handleHiddenInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' || e.key === 'Enter') {
      socket.emit('remote_input', { type: 'keydown', key: e.key });
    }
  };

  const toggleKeyboard = () => {
    setShowKeyboard(!showKeyboard);
    if (!showKeyboard && inputRef.current) inputRef.current.focus();
  };

  return (
    <div className="flex flex-col h-full bg-cyber-surface/30 backdrop-blur-md rounded-[2rem] border border-white/5 overflow-hidden">
      <div className="p-4 md:p-6 border-b border-white/5 flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyber-primary/10 rounded-lg">
            <Monitor className="w-5 h-5 text-cyber-primary" />
          </div>
          <div>
            <h2 className="text-sm md:text-lg font-bold text-white tracking-wider uppercase font-mono">Remote Desktop</h2>
            <p className="text-[8px] md:text-[10px] text-gray-400 font-mono uppercase tracking-tighter">Resolution: {resolution.width}x{resolution.height}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={toggleKeyboard}
            className={`p-2.5 rounded-xl border transition-all ${showKeyboard ? 'bg-cyber-primary text-black border-cyber-primary' : 'bg-white/5 text-white border-white/10 hover:bg-white/10'}`}
          >
            <Keyboard className="w-4 h-4" />
          </button>
          <button 
            onClick={toggleStream}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-mono text-xs font-bold tracking-widest transition-all ${isStreaming ? 'bg-red-500/10 text-red-500' : 'bg-cyber-primary text-black'}`}
          >
            {isStreaming ? <><Square className="w-4 h-4" /> STOP</> : <><Play className="w-4 h-4" /> CONNECT</>}
          </button>
        </div>
      </div>

      <div 
        ref={containerRef}
        onKeyDown={handleKeyDown}
        tabIndex={0}
        className="flex-1 relative bg-[#050505] overflow-hidden flex items-center justify-center cursor-crosshair outline-none touch-none"
      >
        <input 
          ref={inputRef}
          type="text" 
          className="absolute opacity-0 pointer-events-none"
          onChange={handleHiddenInputChange}
          onKeyDown={handleHiddenInputKeyDown}
        />

        {!isStreaming ? (
          <div className="flex flex-col items-center gap-6 opacity-30 group-hover:opacity-50 transition-opacity">
            <Monitor className="w-20 md:w-24 h-20 md:h-24 text-cyber-primary" />
            <p className="text-[10px] md:text-sm font-mono tracking-[0.5em] text-white uppercase animate-pulse">Ready to Connect</p>
          </div>
        ) : (
          <div className="relative w-full h-full flex items-center justify-center">
            {frame ? (
              <img 
                ref={imageRef}
                src={frame} 
                alt="Remote Screen" 
                onLoad={() => setIsFirstFrame(false)}
                onMouseMove={handleMouseEvent}
                onMouseDown={handleMouseEvent}
                onMouseUp={handleMouseEvent}
                onTouchStart={handleTouchEvent}
                onTouchMove={handleTouchEvent}
                onTouchEnd={handleTouchEvent}
                className={`max-w-full max-h-full shadow-2xl select-none pointer-events-auto transition-opacity duration-300 ${isFirstFrame ? 'opacity-0' : 'opacity-100'}`}
                draggable={false}
              />
            ) : (
              <div className="w-8 h-8 border-2 border-cyber-primary border-t-transparent rounded-full animate-spin"></div>
            )}
            
            <div className="absolute top-4 right-4 opacity-50">
              <div className="p-3 bg-black/80 backdrop-blur-md rounded-2xl border border-white/10 flex items-center gap-3">
                <MousePointer2 className="w-4 h-4 text-cyber-primary" />
                <span className="text-[10px] font-mono text-gray-400">Live Connection</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-3 md:p-4 bg-black/40 border-t border-white/5 flex items-center justify-between">
        <div className="flex gap-4">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-cyber-primary"></div>
            <span className="text-[8px] md:text-[9px] font-mono text-gray-400 uppercase tracking-widest">Live Streaming</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
           <Fullscreen className="w-3 h-3 text-gray-700" />
           <span className="text-[8px] md:text-[9px] font-mono text-gray-600 uppercase tracking-widest">Adaptive Scaling</span>
        </div>
      </div>
    </div>
  );
}
