import { useState } from 'react';
import { Bot, Send, Terminal as TerminalIcon, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import api from '../api';
import { motion, AnimatePresence } from 'framer-motion';

interface HistoryItem {
  command: string;
  output: string;
  timestamp: Date;
  status: 'success' | 'error';
}

const SUGGESTIONS = [
  "clean temp files",
  "system info",
  "flush dns",
  "list connections",
  "check disk",
  "ip configuration",
  "uptime"
];

export default function AIAssistant() {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(false);

  const handleExecute = async (cmd: string) => {
    if (!cmd.trim() || loading) return;
    
    setLoading(true);
    try {
      const res = await api.post('/ai/execute', { command: cmd });
      setHistory(prev => [{
        command: cmd,
        output: res.data.output || res.data.message,
        timestamp: new Date(),
        status: 'success'
      }, ...prev]);
      setInput('');
    } catch (err: any) {
      setHistory(prev => [{
        command: cmd,
        output: err.response?.data?.error || 'System error',
        timestamp: new Date(),
        status: 'error'
      }, ...prev]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-cyber-surface/30 backdrop-blur-md rounded-[2rem] border border-white/5 overflow-hidden">
      <div className="p-6 border-b border-white/5 flex items-center gap-3">
        <div className="p-2 bg-cyber-primary/10 rounded-lg shadow-[0_0_15px_rgba(0,255,204,0.1)]">
          <Bot className="w-5 h-5 text-cyber-primary" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white tracking-wider uppercase font-mono">AI Assistant</h2>
          <p className="text-[10px] text-gray-400 font-mono uppercase tracking-tighter">Intelligent System Control</p>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 custom-scrollbar space-y-6">
        {/* History Area */}
        <AnimatePresence initial={false}>
          {loading && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-2xl border bg-cyber-primary/5 border-cyber-primary/10 mb-6"
            >
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-2 h-2 bg-cyber-primary rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-cyber-primary rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-cyber-primary rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <span className="text-[10px] font-mono text-cyber-primary uppercase tracking-[0.2em] ml-2">Executing Protocol...</span>
              </div>
              <div className="h-4 bg-white/5 rounded-md animate-pulse w-3/4"></div>
            </motion.div>
          )}

          {history.length === 0 && !loading ? (
            <div className="h-full flex flex-col items-center justify-center opacity-30 space-y-4">
              <Sparkles className="w-12 h-12 text-cyber-primary animate-pulse" />
              <p className="text-xs font-mono tracking-widest uppercase text-center">Waiting for Command Input...</p>
            </div>
          ) : (
            history.map((item, i) => (
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                key={i} 
                className={`p-4 rounded-2xl border ${item.status === 'success' ? 'bg-cyber-primary/5 border-cyber-primary/10' : 'bg-red-500/5 border-red-500/10'}`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <TerminalIcon className="w-3 h-3 text-gray-500" />
                    <span className="text-[10px] font-mono text-white/80 uppercase">{item.command}</span>
                  </div>
                  {item.status === 'success' ? (
                    <CheckCircle2 className="w-3 h-3 text-cyber-primary" />
                  ) : (
                    <AlertCircle className="w-3 h-3 text-red-500" />
                  )}
                </div>
                <pre className="text-[11px] font-mono text-gray-400 whitespace-pre-wrap bg-black/40 p-3 rounded-xl border border-white/5 leading-relaxed">
                  {item.output}
                </pre>
                <div className="mt-2 text-[8px] text-gray-600 font-mono text-right">
                  {item.timestamp.toLocaleTimeString()}
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      <div className="p-6 bg-black/40 border-t border-white/5">
        {/* Suggestions */}
        <div className="flex flex-wrap gap-2 mb-4">
          {SUGGESTIONS.map(s => (
            <button 
              key={s}
              onClick={() => handleExecute(s)}
              className="text-[9px] font-mono px-3 py-1.5 bg-white/5 hover:bg-cyber-primary/10 hover:text-cyber-primary border border-white/5 hover:border-cyber-primary/30 rounded-full transition-all uppercase tracking-tighter"
            >
              {s}
            </button>
          ))}
        </div>

        <form 
          onSubmit={(e) => { e.preventDefault(); handleExecute(input); }}
          className="relative"
        >
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a system command (e.g. 'clean temp files')..."
            className="w-full bg-cyber-bg/50 border border-white/10 rounded-2xl pl-6 pr-14 py-4 text-sm font-mono text-white placeholder:text-gray-700 focus:border-cyber-primary/40 outline-none transition-all shadow-inner"
          />
          <button 
            type="submit"
            disabled={loading}
            className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-cyber-primary text-black rounded-xl hover:brightness-110 active:scale-95 transition-all disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
