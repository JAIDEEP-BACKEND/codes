import { useState, useEffect } from 'react';
import { Cpu, Server, HardDrive, Activity, Zap, ShieldCheck, Lock, Moon, RotateCcw, Power, Camera, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import api from '../api';

export default function SystemStats() {
  const [stats, setStats] = useState<any>(null);
  const [isPowerLoading, setIsPowerLoading] = useState<string | null>(null);
  const [screenshotUrl, setScreenshotUrl] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await api.get('/system');
        setStats(res.data);
      } catch (e) {
        console.error(e);
      }
    };

    fetchStats();
    const interval = setInterval(fetchStats, 5000);
    return () => clearInterval(interval);
  }, []);

  const handlePowerAction = async (action: string) => {
    const labels: any = {
      lock: 'Lock Workstation',
      sleep: 'Sleep',
      restart: 'Restart System',
      shutdown: 'Shutdown System'
    };

    if (['restart', 'shutdown'].includes(action)) {
      if (!confirm(`CRITICAL: Confirm ${labels[action]} protocol? This will disconnect all users.`)) return;
    }

    setIsPowerLoading(action);
    try {
      await api.post('/system/power', { action });
      alert(`Protocol ${action.toUpperCase()} initiated.`);
    } catch (e) {
      alert('Failed to execute power command.');
    } finally {
      setIsPowerLoading(null);
    }
  };

  const handleCaptureScreen = async () => {
    setIsCapturing(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${api.defaults.baseURL}/system/screenshot`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) throw new Error('Failed to capture');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setScreenshotUrl(url);
    } catch (e) {
      alert('Failed to capture remote screen.');
    } finally {
      setIsCapturing(false);
    }
  };

  if (!stats) return (
    <div className="flex-1 flex items-center justify-center font-mono text-[10px] text-cyber-primary animate-pulse tracking-widest uppercase">
      Initializing System Data...
    </div>
  );

  const memPercent = ((stats.memory.used / stats.memory.total) * 100).toFixed(1);
  const diskPercent = stats.disk ? ((stats.disk.used / stats.disk.size) * 100).toFixed(1) : "0";

  const statCards = [
    { label: 'CPU Load', val: `${stats.cpu.toFixed(1)}%`, icon: Cpu, percent: stats.cpu, color: 'text-cyber-primary' },
    { label: 'Memory Usage', val: `${memPercent}%`, icon: Server, percent: parseFloat(memPercent), color: 'text-cyber-primary' },
    { label: 'Disk Usage', val: `${diskPercent}%`, icon: HardDrive, percent: parseFloat(diskPercent), color: 'text-cyber-secondary' },
  ];

  const powerButtons = [
    { id: 'lock', label: 'LOCK', icon: Lock, color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { id: 'sleep', label: 'SLEEP', icon: Moon, color: 'text-purple-400', bg: 'bg-purple-400/10' },
    { id: 'restart', label: 'REBOOT', icon: RotateCcw, color: 'text-orange-400', bg: 'bg-orange-400/10' },
    { id: 'shutdown', label: 'POWER', icon: Power, color: 'text-red-500', bg: 'bg-red-500/10' },
  ];

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar p-6 lg:p-8">
      <div className="mb-8 flex items-center space-x-4">
        <div className="p-3 glass rounded-2xl border-cyber-secondary/30">
          <Activity className="w-6 h-6 text-cyber-secondary animate-pulse" />
        </div>
        <div>
          <h2 className="text-xl font-mono text-white tracking-widest font-bold uppercase">System Status</h2>
          <p className="text-[10px] text-gray-500 font-mono tracking-tighter uppercase opacity-50">Real-time diagnostics</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6 mb-8">
        {statCards.map((card, i) => (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={card.label}
            className="glass rounded-3xl p-6 border-white/5 relative overflow-hidden group"
          >
            <div className="absolute -top-4 -right-4 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
              <card.icon className="w-32 h-32 text-white" />
            </div>

            <div className="flex items-center space-x-3 mb-6 relative z-10">
              <div className={`p-2 rounded-lg bg-black/40 ${card.color}`}>
                <card.icon className="w-4 h-4" />
              </div>
              <h3 className="font-mono text-[10px] text-gray-500 tracking-widest font-bold">{card.label}</h3>
            </div>

            <div className="flex items-end space-x-3 mb-4 relative z-10">
              <span className="text-4xl font-mono text-white font-bold">{card.val}</span>
              {card.percent > 80 && <Zap className="w-4 h-4 text-cyber-secondary animate-bounce mb-2" />}
            </div>

            <div className="w-full bg-black/40 rounded-full h-1.5 overflow-hidden relative z-10">
              <motion.div
                className={`h-full ${parseFloat(card.val) > 80 ? 'bg-cyber-secondary' : 'bg-cyber-primary shadow-[0_0_8px_#00ffcc]'}`}
                initial={{ width: 0 }}
                animate={{ width: `${card.percent}%` }}
                transition={{ duration: 1 }}
              />
            </div>
          </motion.div>
        ))}

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass rounded-3xl p-6 border-white/5 md:col-span-1 flex flex-col justify-center"
        >
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 rounded-lg bg-black/40 text-blue-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <h3 className="font-mono text-[10px] text-gray-500 tracking-widest font-bold">ENVIRONMENT</h3>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center border-b border-white/5 pb-3">
              <span className="text-[10px] font-mono text-gray-400">OPERATING SYSTEM</span>
              <span className="text-xs font-mono text-white uppercase">{stats.os}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-mono text-gray-400">SECURITY STATUS</span>
              <span className="text-xs font-mono text-cyber-primary">ENCRYPTED</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* POWER CONTROLS */}
      <div className="mb-4">
        <h3 className="font-mono text-[10px] text-gray-500 tracking-[0.3em] uppercase mb-4 px-2">Power Management</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {powerButtons.map((btn) => (
            <button
              key={btn.id}
              onClick={() => handlePowerAction(btn.id)}
              disabled={isPowerLoading !== null}
              className={`glass p-6 rounded-[2rem] border-white/5 flex flex-col items-center justify-center space-y-3 active:scale-95 transition-all group relative overflow-hidden ${isPowerLoading === btn.id ? 'opacity-50 grayscale' : ''}`}
            >
              <div className={`p-4 rounded-2xl ${btn.bg} ${btn.color} group-hover:scale-110 transition-transform`}>
                <btn.icon className="w-6 h-6" />
              </div>
              <span className={`font-mono text-[10px] font-bold tracking-widest ${btn.color}`}>{btn.label}</span>
              {isPowerLoading === btn.id && (
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                </div>
              )}
            </button>
          ))}

          <button
            onClick={handleCaptureScreen}
            disabled={isCapturing}
            className={`glass p-6 rounded-[2rem] border-cyber-primary/20 flex flex-col items-center justify-center space-y-3 active:scale-95 transition-all group relative overflow-hidden bg-cyber-primary/5`}
          >
            <div className={`p-4 rounded-2xl bg-cyber-primary/10 text-cyber-primary group-hover:scale-110 transition-transform`}>
              <Camera className="w-6 h-6" />
            </div>
            <span className={`font-mono text-[10px] font-bold tracking-widest text-cyber-primary`}>CAPTURE</span>
            {isCapturing && (
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-cyber-primary/20 border-t-cyber-primary rounded-full animate-spin"></div>
              </div>
            )}
          </button>
        </div>
      </div>

      {/* SCREENSHOT PREVIEW MODAL */}
      <AnimatePresence>
        {screenshotUrl && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm p-4 lg:p-12 flex flex-col items-center justify-center"
          >
            <div className="absolute top-6 right-6 flex items-center space-x-4">
              <a
                href={screenshotUrl}
                download="nexus_capture.jpg"
                className="font-mono text-[10px] text-cyber-primary border border-cyber-primary/30 px-4 py-2 rounded-full hover:bg-cyber-primary/10 transition-all tracking-widest uppercase"
              >
                Download Image
              </a>
              <button
                onClick={() => setScreenshotUrl(null)}
                className="p-2 glass rounded-full text-white hover:text-red-400 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="relative max-w-full max-h-full rounded-2xl overflow-hidden border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)]"
            >
              <img src={screenshotUrl} alt="Remote Screen" className="max-w-full max-h-[80vh] object-contain" />
              <div className="absolute bottom-4 left-4 font-mono text-[10px] text-white/30 tracking-tighter uppercase">
                Remote_Visual_Feed // Session_{Math.random().toString(36).substring(7).toUpperCase()}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
