import { useState, useEffect } from 'react';
import { Users, Shield, Plus, Edit, Trash2 } from 'lucide-react';
import api from '../api';

export default function UserManagement({ socket }: { socket: any }) {
  const [users, setUsers] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);

  const [formData, setFormData] = useState({
    username: '',
    password: '',
    role: 'user',
    canUpload: true,
    canDelete: false,
    canDownload: true
  });

  const fetchUsers = async () => {
    try {
      const res = await api.get('/users');
      setUsers(res.data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchUsers();
    socket.on('users_update', fetchUsers);
    return () => socket.off('users_update', fetchUsers);
  }, []);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingUser) {
        await api.put(`/users/${editingUser.id}`, formData);
      } else {
        await api.post('/users', formData);
      }
      setShowModal(false);
    } catch (e: any) {
      console.error(e);
      alert(`Failed to save user: ${e.response?.data?.error || e.message}`);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this user?')) return;
    try {
      await api.delete(`/users/${id}`);
    } catch (e) {
      console.error(e);
    }
  };

  const openNewUser = () => {
    setEditingUser(null);
    setFormData({ username: '', password: '', role: 'user', canUpload: true, canDelete: false, canDownload: true });
    setShowModal(true);
  };

  const openEditUser = (user: any) => {
    setEditingUser(user);
    setFormData({
      username: user.username,
      password: '',
      role: user.role,
      canUpload: !!user.canUpload,
      canDelete: !!user.canDelete,
      canDownload: !!user.canDownload
    });
    setShowModal(true);
  };

  return (
    <div className="h-full p-6 flex flex-col relative">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Users className="w-6 h-6 text-cyber-primary" />
          <h2 className="text-xl font-mono text-white tracking-widest">USER_MANAGEMENT</h2>
        </div>
        <button
          onClick={openNewUser}
          className="flex items-center space-x-2 px-4 py-2 bg-cyber-primary/10 text-cyber-primary border border-cyber-primary/30 rounded-lg hover:bg-cyber-primary/20 transition-all active:scale-95 font-mono text-xs shadow-[0_0_10px_rgba(0,255,204,0.1)]"
        >
          <Plus className="w-4 h-4" />
          <span>ADD_NEW_USER</span>
        </button>
      </div>

      <div className="flex-1 glass rounded-2xl border-cyber-border/30 overflow-hidden flex flex-col shadow-2xl">
        <div className="grid grid-cols-12 gap-4 p-5 bg-white/5 border-b border-cyber-border/50 font-mono text-[10px] text-gray-500 uppercase tracking-widest font-bold">
          <div className="col-span-3">User Identity</div>
          <div className="col-span-2">System Role</div>
          <div className="col-span-5">Access Permissions</div>
          <div className="col-span-2 text-right">Control</div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 font-mono">
          {users.map(user => (
            <div key={user.id} className="grid grid-cols-12 gap-4 p-4 hover:bg-white/5 rounded-xl items-center border-b border-white/5 transition-all group">
              <div className="col-span-3 text-white flex items-center space-x-3">
                <div className={`p-2 rounded-lg ${user.role === 'admin' ? 'bg-cyber-secondary/10 text-cyber-secondary' : 'bg-cyber-primary/10 text-cyber-primary'}`}>
                  <Shield className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold tracking-tight">{user.username}</span>
              </div>
              <div className="col-span-2">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${user.role === 'admin' ? 'bg-cyber-secondary/20 text-cyber-secondary border border-cyber-secondary/30' : 'bg-gray-800 text-gray-400 border border-gray-700'}`}>
                  {user.role}
                </span>
              </div>
              <div className="col-span-5 flex items-center space-x-4">
                <div className="flex items-center space-x-1.5">
                  <div className={`w-1.5 h-1.5 rounded-full ${user.canDownload ? 'bg-green-500 shadow-[0_0_5px_rgba(34,197,94,0.5)]' : 'bg-gray-700'}`}></div>
                  <span className={`text-[10px] ${user.canDownload ? 'text-gray-300' : 'text-gray-600'}`}>VIEW</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <div className={`w-1.5 h-1.5 rounded-full ${user.canUpload ? 'bg-cyber-primary shadow-[0_0_5px_#00ffcc]' : 'bg-gray-700'}`}></div>
                  <span className={`text-[10px] ${user.canUpload ? 'text-gray-300' : 'text-gray-600'}`}>WRITE</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <div className={`w-1.5 h-1.5 rounded-full ${user.canDelete ? 'bg-cyber-secondary shadow-[0_0_5px_#ff0055]' : 'bg-gray-700'}`}></div>
                  <span className={`text-[10px] ${user.canDelete ? 'text-gray-300' : 'text-gray-600'}`}>DELETE</span>
                </div>
              </div>
              <div className="col-span-2 flex justify-end space-x-1 opacity-0 group-hover:opacity-100 transition-all">
                <button onClick={() => openEditUser(user)} className="p-2 text-gray-500 hover:text-cyber-primary hover:bg-cyber-primary/10 rounded-lg transition-all">
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(user.id)}
                  className="p-2 text-gray-500 hover:text-cyber-secondary hover:bg-cyber-secondary/10 rounded-lg transition-all disabled:opacity-0"
                  disabled={user.username === 'admin'}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-cyber-surface border border-cyber-primary rounded-xl p-6 w-full max-w-md shadow-[0_0_30px_rgba(0,255,204,0.1)]">
            <h3 className="text-xl font-mono text-white mb-6 border-b border-cyber-border pb-2">
              {editingUser ? 'EDIT_USER' : 'CREATE_USER'}
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4 font-mono">
              {!editingUser && (
                <div>
                  <label className="block text-[10px] text-gray-500 mb-1 tracking-widest">IDENTITY_TAG</label>
                  <input required type="text" value={formData.username} onChange={e => setFormData({ ...formData, username: e.target.value })} className="w-full bg-cyber-bg border border-cyber-border/50 rounded-lg px-4 py-2.5 text-sm text-white focus:border-cyber-primary focus:ring-1 focus:ring-cyber-primary/30 outline-none transition-all" placeholder="Enter username..." />
                </div>
              )}

              <div>
                <label className="block text-[10px] text-gray-500 mb-1 tracking-widest">
                  ACCESS_KEY {editingUser && <span className="text-cyber-secondary opacity-50 text-[9px] ml-2">(Optional: Type to reset)</span>}
                </label>
                <input required={!editingUser} type="password" value={formData.password} onChange={e => setFormData({ ...formData, password: e.target.value })} className="w-full bg-cyber-bg border border-cyber-border/50 rounded-lg px-4 py-2.5 text-sm text-white focus:border-cyber-primary focus:ring-1 focus:ring-cyber-primary/30 outline-none transition-all" placeholder="••••••••" />
              </div>

              <div>
                <label className="block text-[10px] text-gray-500 mb-1 tracking-widest">SYSTEM_CLEARANCE</label>
                <select value={formData.role} onChange={e => setFormData({ ...formData, role: e.target.value })} className="w-full bg-cyber-bg border border-cyber-border/50 rounded-lg px-4 py-2.5 text-sm text-white focus:border-cyber-primary focus:ring-1 focus:ring-cyber-primary/30 outline-none transition-all appearance-none">
                  <option value="user">STANDARD_USER</option>
                  <option value="admin">SYSTEM_ADMIN</option>
                </select>
              </div>

              <div className="pt-4 border-t border-cyber-border/30">
                <label className="block text-[10px] text-gray-500 mb-3 tracking-widest uppercase">Protocol Permissions</label>
                <div className="grid grid-cols-1 gap-2">
                  <label className="flex items-center space-x-3 cursor-pointer group p-2 hover:bg-white/5 rounded-lg transition-all border border-transparent hover:border-white/5">
                    <input type="checkbox" checked={formData.canDownload} onChange={e => setFormData({ ...formData, canDownload: e.target.checked })} className="accent-cyber-primary w-4 h-4" />
                    <div className="flex flex-col">
                      <span className="text-xs text-gray-300 font-bold group-hover:text-cyber-primary transition-colors">READ_ACCESS</span>
                      <span className="text-[9px] text-gray-600">View and download files</span>
                    </div>
                  </label>
                  <label className="flex items-center space-x-3 cursor-pointer group p-2 hover:bg-white/5 rounded-lg transition-all border border-transparent hover:border-white/5">
                    <input type="checkbox" checked={formData.canUpload} onChange={e => setFormData({ ...formData, canUpload: e.target.checked })} className="accent-cyber-primary w-4 h-4" />
                    <div className="flex flex-col">
                      <span className="text-xs text-gray-300 font-bold group-hover:text-cyber-primary transition-colors">WRITE_ACCESS</span>
                      <span className="text-[9px] text-gray-600">Upload and create folders</span>
                    </div>
                  </label>
                  <label className="flex items-center space-x-3 cursor-pointer group p-2 hover:bg-white/5 rounded-lg transition-all border border-transparent hover:border-white/5">
                    <input type="checkbox" checked={formData.canDelete} onChange={e => setFormData({ ...formData, canDelete: e.target.checked })} className="accent-cyber-primary w-4 h-4" />
                    <div className="flex flex-col">
                      <span className="text-xs text-gray-300 font-bold group-hover:text-cyber-primary transition-colors">DELETE_ACCESS</span>
                      <span className="text-[9px] text-gray-600">Remove and relocate files</span>
                    </div>
                  </label>
                </div>
              </div>

              <div className="flex space-x-3 pt-6">
                <button type="submit" className="flex-1 bg-cyber-primary/10 text-cyber-primary border border-cyber-primary/30 py-2.5 rounded-lg hover:bg-cyber-primary/20 transition-all active:scale-95 font-bold text-xs tracking-widest shadow-[0_0_15px_rgba(0,255,204,0.1)]">
                  COMMIT_CHANGES
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="px-6 bg-transparent text-gray-500 border border-cyber-border/50 py-2.5 rounded-lg hover:bg-white/5 transition-all text-xs font-bold">
                  CANCEL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
