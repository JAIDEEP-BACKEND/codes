import { useState, useEffect } from 'react';
import { Terminal, Clock, User, Activity } from 'lucide-react';
import { motion } from 'framer-motion';
import api from '../api';

export default function ActivityLog({ socket }: { socket: any }) {
  const [logs, setLogs] = useState<any[]>([]);

  const fetchLogs = async () => {
    try {
      const res = await api.get('/logs');
      setLogs(res.data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchLogs();
    socket.on('activity_update', fetchLogs);
    return () => socket.off('activity_update', fetchLogs);
  }, []);

  return (
    <div className="h-full p-4 lg:p-8 flex flex-col bg-cyber-bg">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="p-3 glass rounded-2xl border-cyber-primary/30 relative">
            <Activity className="w-6 h-6 text-cyber-primary" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-cyber-primary rounded-full animate-ping opacity-20"></div>
          </div>
          <div>
            <h2 className="text-xl font-mono text-white tracking-widest font-bold uppercase">Activity Logs</h2>
            <p className="text-[10px] text-gray-500 font-mono tracking-tighter uppercase opacity-50">System Event History</p>
          </div>
        </div>
        <div className="flex items-center space-x-2 px-3 py-1 bg-cyber-primary/5 border border-cyber-primary/10 rounded-full">
          <div className="w-1.5 h-1.5 bg-cyber-primary rounded-full animate-pulse"></div>
          <span className="text-[8px] font-mono text-cyber-primary uppercase tracking-[0.2em]">Live</span>
        </div>
      </div>

      <div className="flex-1 glass rounded-3xl border-white/5 overflow-hidden flex flex-col shadow-2xl">
        <div className="overflow-y-auto custom-scrollbar p-3 flex-1">
          {logs.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full opacity-20 space-y-4">
              <Terminal className="w-12 h-12 text-gray-500" />
              <p className="font-mono text-xs uppercase tracking-widest">No recent activity</p>
            </div>
          ) : (
            logs.map((log, i) => (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                key={log.id}
                className="flex flex-col space-y-2 mb-3 p-4 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.03] rounded-2xl transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="p-1.5 bg-cyber-secondary/10 rounded-lg">
                      <User className="w-3 h-3 text-cyber-secondary" />
                    </div>
                    <span className="font-mono text-[11px] text-white font-bold tracking-tight">{log.username}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-gray-600">
                    <Clock className="w-3 h-3" />
                    <span className="font-mono text-[9px] uppercase">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 bg-cyber-primary/10 text-cyber-primary font-mono text-[9px] font-bold rounded border border-cyber-primary/20 uppercase tracking-tighter">
                    [{log.action}]
                  </span>
                  <span className="font-mono text-[11px] text-gray-400 flex-1 truncate">{log.details}</span>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
