# 🛡️ NEXUS // SECURE_FILE_ECOSYSTEM

[![Status](https://img.shields.io/badge/STATUS-OPERATIONAL-00ffcc?style=for-the-badge&logo=statuspage&logoColor=black)]()
[![Version](https://img.shields.io/badge/VERSION-1.0.0-ff0055?style=for-the-badge)]()
[![Environment](https://img.shields.io/badge/ENV-PRODUCTION-blue?style=for-the-badge)]()

> **NEXUS** is a high-performance, browser-based file management and remote system control suite. Designed with a cyber-aesthetic and hardened security, it transforms any machine into a centralized, accessible, and secure data hub.

---

## ⚡ CORE_PROTOCOLS

### 📂 Advanced File Management
*   **Kernel-Level Access:** Navigate the host file system with high-speed indexing.
*   **Data Stream:** Secure Upload/Download/Preview of any file type.
*   **Structural Control:** Instant folder creation, renaming, and atomic move operations.

### 💻 Remote Command & Control
*   **Remote Shell:** Direct terminal access via a restricted browser-based console.
*   **Visual Feed:** Real-time screen capture of the host machine.
*   **Power Management:** Remote Lock, Sleep, Restart, and Shutdown protocols.

### 📊 Node Telemetry
*   **Real-time Vitals:** Live tracking of CPU load, Memory allocation, and Disk utilization.
*   **Live Stream Monitor:** WebSocket-driven activity logs for every operation.

---

## 🔐 SECURITY_STACK

*   **Stateless Auth:** JSON Web Tokens (JWT) with 24-hour expiration cycles.
*   **Cryptographic Hashing:** Every password is salted and hashed using `bcrypt`.
*   **Traversal Protection:** Path resolution algorithms prevent directory traversal attacks.
*   **Rate Limiting:** Integrated flood protection to mitigate brute-force attempts.
*   **Role-Based Access (RBAC):** Granular permissions for Admins vs. Standard users.

---

## 🚀 DEPLOYMENT_MANUAL

### 📡 Prerequisites
- **Node.js** v20+ (Engine)
- **NPM** (Package Controller)

### 1️⃣ Initialize Core (Backend)
```powershell
cd backend
npm install
npm start
```
*Port: `8080` // Default Creds: `admin` / `admin123`*

### 2️⃣ Initialize Interface (Frontend)
```powershell
cd frontend
npm install
npm run dev
```
*Host: `localhost:5173`*

### ⚡ Quick Start (Root)
```powershell
npm run install:all
npm run dev
```


---

## 🛠️ TECH_SPECIFICATIONS

| Layer | Technology | Purpose |
| :--- | :--- | :--- |
| **Frontend** | React 19 + Vite | High-speed reactive interface |
| **Styling** | Tailwind CSS 4 | Cyber-themed Glassmorphic design |
| **Backend** | Node.js + Express | RESTful API & System Bridge |
| **Database** | SQLite | Lightweight, localized persistence |
| **Real-time** | Socket.io | Bi-directional event streaming |

---

## 🌑 THEME_CONFIG

NEXUS uses a curated **Cyber-Dark** palette:
- `PRIMARY`: `#00ffcc` (Neon Teal)
- `SECONDARY`: `#ff0055` (Crimson Pulse)
- `BACKGROUND`: `#050505` (Deep Void)

---

### ⚠️ SYSTEM_WARNING
*This tool provides direct access to the host file system. Ensure it is deployed behind a secure firewall or VPN for public access. Use Cloudflare Tunnels for secure external routing.*

---
**Developed by the NEXUS Engineering Team**
